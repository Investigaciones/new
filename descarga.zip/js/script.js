 document.addEventListener("DOMContentLoaded", function() {
    // Crear el contenedor principal
    const body = document.body;

    // Crear header
    const header = document.createElement('header');
    const h1 = document.createElement('h1');
    h1.textContent = "AMBIENTE Y SUSTENTABILIDAD";
    header.appendChild(h1);

    // Crear navegación
    const nav = document.createElement('nav');
    const links = [
        "Inicio", "La tierra", "Estructura y funcionamiento",
        "Sistema viviente", "Flujo de energía", "Sustentabilidad",
        "Recursos y contacto", "Subir contenido"
    ];
    links.forEach(link => {
        const a = document.createElement('a');
        a.href = `#${link.toLowerCase().replace(/ /g, '-')}`;
        a.textContent = link;
        nav.appendChild(a);
    });
    header.appendChild(nav);
    body.appendChild(header);

    // Crear contenido principal
    const content = document.createElement('div');
    content.className = 'content';
    
    // Sección de Inicio
    const inicio = document.createElement('section');
    inicio.id = 'inicio';
    inicio.innerHTML = `<h2>Inicio</h2>
    <p>Bienvenido a nuestra página dedicada al planeta Tierra como un sistema viviente. Explora nuestras secciones para conocer más sobre cómo la Tierra funciona como un ecosistema integral y cómo sus diversos componentes interactúan para mantener el equilibrio.</p>`;
    content.appendChild(inicio);

    // Sección ¿Qué es la Tierra?
    const tierra = document.createElement('section');
    tierra.id = 'que-es-la-tierra';
    tierra.innerHTML = `<h2>¿Qué es la Tierra?</h2>
    <p>La Tierra es el tercer planeta del sistema solar y el único conocido con vida...</p>
    <img src="https://www.masazulplaneta.com.ar/wp-content/uploads/2020/09/Nuestra-casa-el-Planeta-Tierra-desde-el-espacio-3_comp.jpg" alt="La Tierra desde el Espacio">`;
    content.appendChild(tierra);

    // Añadir más secciones siguiendo el mismo patrón...

    // Agregar el contenido al cuerpo
    body.appendChild(content);

    // Crear footer
    const footer = document.createElement('footer');
    footer.innerHTML = `<p>&copy; 2023 AMBIENTE Y SUSTENTABILIDAD. Todos los derechos reservados.</p>`;
    body.appendChild(footer);

    // Sección de subir contenido
    const subirContenido = document.createElement('section');
    subirContenido.id = 'subir-contenido';
    subirContenido.innerHTML = `<h1>Subir contenido</h1>
    <p>Aquí puedes subir y compartir tus archivos :</p>
    <input type="file" id="pdfInput" accept="application/pdf">
    <br><br>
    <a id="downloadLink" style="display: none;">Descargar PDF</a>`;

    subirContenido.querySelector('#pdfInput').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file && file.type === 'application/pdf') {
            const fileURL = URL.createObjectURL(file);
            const downloadLink = document.getElementById('downloadLink');
            downloadLink.href = fileURL;
            downloadLink.download = file.name;
            downloadLink.style.display = 'inline';
            downloadLink.textContent = `Descargar ${file.name}`;
        } else {
            alert('Por favor, sube un archivo PDF.');
        }
    });

    content.appendChild(subirContenido);
});
